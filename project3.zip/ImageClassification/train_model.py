import os
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.models as models
from torchvision import datasets, transforms
import argparse
import smdebug.pytorch as smd

import numpy as np

from PIL import ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True

def convert_decimals(para):
    if type(para) == torch.Tensor:
        para = float(np.around(para, 2))
        para = round(para, 2)
    else:
        para = round(para, 2)
    return para

def test(model, test_loader, criterion, hook):
    model.eval()
    hook.set_mode(smd.modes.EVAL)

    running_loss = 0
    running_corrects = 0

    for inputs, labels in test_loader:
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        _, preds = torch.max(outputs, 1)
        running_loss += loss.item() * inputs.size(0)
        running_corrects += torch.sum(preds == labels.data).item()

    total_loss = running_loss / len(test_loader.dataset)
    total_acc = running_corrects / len(test_loader.dataset)
    
    total_loss = convert_decimals(total_loss)
    total_acc = convert_decimals(total_acc)
    
    print(f"Test - Loss: {total_loss}, Accuracy: {total_acc * 100}%")


def train(model, train_loader, valid_loader, criterion, optimizer, hook):
    image_dataset={'Train':train_loader, 'Valid':valid_loader}
    
    for phase in ['Train', 'Valid']:
        if phase == 'Train':
            model.train()
            hook.set_mode(smd.modes.TRAIN)
        else:
            model.eval()
            hook.set_mode(smd.modes.EVAL)
            
        running_loss = 0.0
        running_corrects = 0
        
        for inputs, labels in image_dataset[phase]:
            
            if phase == 'Train':
                optimizer.zero_grad()
                outputs = model(inputs)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()
            else:
                outputs = model(inputs)
                loss = criterion(outputs, labels)
                
            _, preds = torch.max(outputs, 1)
            running_loss += loss.item() * inputs.size(0)
            running_corrects += torch.sum(preds == labels.data)
            
        epoch_loss = running_loss / len(image_dataset[phase].dataset)
        epoch_acc = running_corrects / len(image_dataset[phase].dataset)
        
        epoch_loss = convert_decimals(epoch_loss)
        epoch_acc = convert_decimals(epoch_acc)
        
        print(f'{phase} - Loss:{epoch_loss}, Accuracy:{epoch_acc * 100}%')



def net():
    model = models.resnet18(pretrained=True)

    for param in model.parameters():
        param.requires_grad = False

    num_features = model.fc.in_features
    model.fc = nn.Sequential(
        nn.Linear(num_features, 133))

    return model


def create_data_loaders(data_train, data_valid, data_test, batch_size):
    train_transforms = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor()])

    valid_transforms = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor()])
    
    test_transforms = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor()])
    
    trainset = datasets.ImageFolder(root=data_train, transform=train_transforms)
    validset = datasets.ImageFolder(root=data_valid, transform=valid_transforms)
    testset = datasets.ImageFolder(root=data_test, transform=test_transforms)
    
    return (
        torch.utils.data.DataLoader(trainset, batch_size=batch_size, shuffle=True),
        torch.utils.data.DataLoader(validset, batch_size=batch_size, shuffle=False),
        torch.utils.data.DataLoader(testset, batch_size=batch_size, shuffle=False))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--batch-size", type=int, default=64, metavar="N", help="input batch size for training (default: 64)")
    parser.add_argument("--test-batch-size", type=int, default=1000, metavar="N", help="input batch size for testing (default: 1000)")
    parser.add_argument("--epochs", type=int, default=14, metavar="N", help="number of epochs to train (default: 14)")
    parser.add_argument("--lr", type=float, default=1.0, metavar="LR", help="learning rate (default: 1.0)")
    parser.add_argument('--model-dir', type=str, default=os.environ['SM_MODEL_DIR'])
    parser.add_argument('--train', type=str, default=os.environ['SM_CHANNEL_TRAIN'])
    parser.add_argument('--valid', type=str, default=os.environ['SM_CHANNEL_VALID'])
    parser.add_argument('--test', type=str, default=os.environ['SM_CHANNEL_TEST'])
    args = parser.parse_args()

    model = net()
    loss_criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.fc.parameters(), lr=args.lr)

    hook = smd.Hook.create_from_json_file()
    hook.register_module(model)
    hook.register_loss(loss_criterion)


    train_loader, valid_loader, test_loader = create_data_loaders(args.train, args.valid, args.test, args.batch_size)
    
    for epoch in range(1, args.epochs + 1):
        print('Epoch:', epoch)
        train(model, train_loader, valid_loader, loss_criterion, optimizer, hook)
        test(model, test_loader, loss_criterion, hook)

    path = os.path.join(args.model_dir, "model.pth")
    torch.save(model.cpu().state_dict(), path)


if __name__ == '__main__':
    main()


